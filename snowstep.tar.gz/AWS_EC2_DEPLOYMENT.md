# Deploy Snowstep to AWS EC2

The GitHub Actions workflow in `.github/workflows/deploy-ec2.yml` builds the Vite frontend, provisions the EC2/CloudFront resources with CloudFormation, and deploys the Express API through AWS Systems Manager. The EC2 instance serves the frontend with Nginx and runs the API with PM2. Port 22 is not opened; instance management uses SSM.

## Before the first deployment

1. In GitHub, open **Settings → Secrets and variables → Actions**.
2. Add these repository **variables**:

   | Variable | Example | Purpose |
   | --- | --- | --- |
   | `AWS_REGION` | `us-east-1` | AWS region with a default VPC and public subnet |
   | `CFN_STACK_NAME` | `snowstep-production` | Stable CloudFormation stack name |

3. Add these repository **secrets**:

   | Secret | Purpose |
   | --- | --- |
   | `AWS_ACCESS_KEY_ID` | IAM credentials for the GitHub deploy workflow |
   | `AWS_SECRET_ACCESS_KEY` | Matching IAM secret key |
   | `AWS_SESSION_TOKEN` | Required only when using temporary AWS credentials |
   | `MONGODB_URI` | Reachable MongoDB connection string, normally MongoDB Atlas |
   | `AUTH_TOKEN_SECRET` | Random secret of at least 32 characters |

   Use a dedicated AWS identity with permissions to manage the stack's CloudFormation, EC2, IAM role passing, Elastic IP, S3, Systems Manager, Parameter Store, KMS, and CloudFront resources. Do not use root credentials. Never commit or paste secrets into source files, workflow logs, or chat.

4. Ensure the selected AWS region has a default VPC and public subnet with outbound internet access. The workflow discovers these automatically.
5. Start the workflow from **Actions → Deploy Snowstep to AWS EC2 → Run workflow**, or push to `main`/`master`.

## MongoDB Atlas

The EC2 server cannot reach MongoDB Compass at `127.0.0.1`; that address refers to the EC2 machine itself. Put a valid Atlas connection URI in the `MONGODB_URI` GitHub secret, with `/snowstep` as its database path if that is the database you intend to use. The password must be URL-encoded if it contains reserved URI characters.

On the first run, the workflow creates the infrastructure and prints the EC2 Elastic IP. Add that IPv4 address as an `/32` entry in Atlas **Network Access**, then rerun the workflow if the API health check failed before the allowlist was updated. The workflow checks that the API can connect to MongoDB before reporting a successful deployment.

Products in the local Compass database do not automatically appear in Atlas. If Atlas is empty, run the existing backend seeder once from a trusted environment configured with the Atlas URI (`npm --prefix backend run seed`). Do not use the local URI for a cloud deployment.

## After deployment

The workflow logs the CloudFront HTTPS URL. CloudFront may take several minutes to finish its initial distribution deployment. The API is available under the same origin at `/api`; Nginx serves the frontend and proxies the API to the local Express process.

The stack creates billable AWS resources, including EC2 and CloudFront. Review AWS pricing and budgets before deploying. To remove the deployment, first empty the private artifact S3 bucket and then delete the CloudFormation stack. Also delete the `/snowstep-production/` Systems Manager parameters (or use the path matching your stack name) and remove the EC2 IP from the Atlas access list. Deleting the stack does not delete the MongoDB Atlas database.
